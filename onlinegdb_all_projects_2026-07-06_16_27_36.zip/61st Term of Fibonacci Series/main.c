#include <stdio.h>
int main() {
int targetTerm = 61;
unsigned long long t1 = 0, t2 = 1, nextTerm = 0;
if (targetTerm == 1) {
nextTerm = t1;
} else if (targetTerm == 2) {
nextTerm = t2;
} else {
for (int i = 3; i <= targetTerm; i++) {
nextTerm = t1 + t2;
t1 = t2;
t2 = nextTerm;
}
}
printf("The %dst term of Fibonacci series is: %llu\n", targetTerm, nextTerm);
return 0;
}