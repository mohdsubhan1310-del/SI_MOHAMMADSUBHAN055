#include <stdio.h>
int main()
{
    int arr[9]={1, 2, 3, 4, 5, 6, 7, 8, 9};
    int k, i, j, last;
    printf("Enter value of K: ");
    scanf("%d", &k);
    k = k % 9;
    for(i = 0; i < k; i++)
    {
        last = arr[9 - 1];
        for(j = 9 - 1; j > 0; j--)
        {
            arr[j] = arr[j - 1];
        }
        arr[0] = last;
    }
    printf("Array after rotation:\n");
    for(i = 0; i < 9; i++)
    {
        printf("%d ", arr[i]);
    }
    return 0;
}
