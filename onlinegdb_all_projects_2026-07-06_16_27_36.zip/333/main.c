#include<stdio.h>
int main(){ 
    int n;
    int i;
    int j;
    int k;
    int a[i];
    printf("Enter number of elements");
    scanf("%d",&n);
    
    printf("Enter element \n");
    for(i=0;i<n;i++)
    {
        scanf("%d",a[i]);
        printf("Duplicate element=");
    
    for(j=0;j<n;j++)
    {
        for (k=j+1;k<n;k++)
        {
            if(a[j]==a[k])
            {printf("%d,a[j}");
                
            }
        }
    }
    }return 0;
}
    