/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int sq;
    int temp;
    int rem;
    int sum;
    int i;
    
    for(int i=0;i>=0;i++) {
    sq=i*i;
    
    temp=sq;
    while(temp>0)
    {
        rem=temp%10;
        sum=sum+rem;
        temp/=10;
        
    }
    if(sum==i)
    {
        countN++;
    }
        countN==15)
        {
            printf("15th Neon number is%d",i)
        break}
    }
   

    return 0;
}