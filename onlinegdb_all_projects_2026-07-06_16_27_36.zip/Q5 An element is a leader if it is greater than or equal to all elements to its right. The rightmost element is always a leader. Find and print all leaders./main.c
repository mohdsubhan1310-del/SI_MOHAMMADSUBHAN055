#include <stdio.h>
int main() {
    int arr[8]={16, 17, 8, 5, 13, 2, 12, 9};
    int maxRight = arr[8-1];   
    int leaders[8];
    int count = 0;
    leaders[count++] = maxRight;
    for (int i = 8-2; i >= 0; i--) {
        if (arr[i] >= maxRight) {
            maxRight = arr[i];
            leaders[count++] = arr[i];
        }
    }
    for (int i = count-1; i >= 0; i--) {
        printf("\nThe leader is %d \n", leaders[i]);
    }
    return 0;
}
