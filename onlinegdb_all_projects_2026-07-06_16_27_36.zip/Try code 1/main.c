//
#include <stdio.h>
int main ()
{
    int a1[9];
    int a2[9];
    int size1,size2,i,j;
    
    printf("Enter the size of first array:");
    scanf("%d",&size1);
    printf("Enter elements:");
    for(i=0;i<size1;i++)
    scanf("%d",&a1[i]);
    
    printf("Enter the size of second array:");
    scanf("%d",&size2);
    printf("Enter elements:");
    for(i=0;i<size2;i++)
    scanf("%d",&a2[i]);
    
    // To defermine the size of array if not entered by user 
     size1=sizeof(a1)/sizeof(a1[0]);
    size2=sizeof(a2)/sizeof(a2[0]);
    int sizeI;
    
    if(size1<size2)
    {
        sizeI=size1;
    }
    else
    {
        sizeI=size2;
    }
    for(int i=0;i<size1;i++)
    {
        for(int j=0;j<size2;j++)
        {
            if(a1[i]==a2[j])
            {
                printf("%d",a1[i]);
                
                break;
            }
        }
    }
    return 0;
}